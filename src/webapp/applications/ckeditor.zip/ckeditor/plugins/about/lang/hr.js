﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'hr', {
	copy: 'Copyright &copy; $1. All rights reserved.',
	dlgTitle: 'O CKEditoru',
	help: 'Provjeri $1 za pomoć.',
	moreInfo: 'Za informacije o licencama posjetite našu web stranicu:',
	title: 'O CKEditoru',
	userGuide: 'Vodič za CKEditor korisnike'
});
