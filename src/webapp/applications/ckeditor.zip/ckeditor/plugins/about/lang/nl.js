﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'nl', {
	copy: 'Copyright &copy; $1. Alle rechten voorbehouden.',
	dlgTitle: 'Over CKEditor',
	help: 'Bekijk de $1 voor hulp.',
	moreInfo: 'Bezoek onze website voor licentieinformatie:',
	title: 'Over CKEditor',
	userGuide: 'CKEditor gebruiksaanwijzing'
} );
