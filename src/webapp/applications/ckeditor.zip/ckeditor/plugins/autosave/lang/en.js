﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'en', {
    loadSavedContent: 'There is a auto-saved version of this content (From "{0}") found. Do you want to open the Compare Dialog, where you can decide to load the auto saved Content?',
    title: 'Compare Temp. Saved Content with the Loaded Content of the Site',
    loadedContent: 'Loaded Content',
    autoSavedContent: 'Auto. Saved Content (From: \'',
	ok: 'Load Auto. Saved Content',
	diffType: 'Diff View Type:',
	sideBySide: 'Side by Side',
	inline: 'Inline'
});
