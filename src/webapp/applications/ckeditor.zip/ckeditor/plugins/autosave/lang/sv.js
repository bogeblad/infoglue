﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('autosave', 'sv', {
    dateFormat: 'LLL',
    autoSaveMessage: 'Auto Saved',
    loadSavedContent: 'There is a auto-saved version of this content (From "{0}") found. Do you want to open the Compare Dialog, where you can decide to load the auto saved Content?',
    loadSavedContent: 'En auto-sparad version av det här innehållet (från "{0}") hittades. Vill du öppna en dialogruta för att jämföra, där du även kan välja att läsa in det auto sparade innehållet?',
    title: 'Jämför Temporärt sparat innehåll med det inladdade innehållet från sidan',
    loadedContent: 'Inladdat innehåll',
    autoSavedContent: 'Autosparat innehåll (från: \'',
	ok: 'Läs in Autosparat innehåll',
	diffType: 'Visa skillnader:',
	sideBySide: 'Sida vid sida',
	inline: 'Ihop'
});
