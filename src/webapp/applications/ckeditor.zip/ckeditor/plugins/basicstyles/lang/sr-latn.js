﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'sr-latn', {
	bold: 'Podebljano',
	italic: 'Kurziv',
	strike: 'Precrtano',
	subscript: 'Indeks',
	superscript: 'Stepen',
	underline: 'Podvučeno'
});
