﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ca', {
	alt: 'Text alternatiu',
	btnUpload: 'Envia-la al servidor',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informació de la imatge',
	lockRatio: 'Bloqueja les proporcions',
	menu: 'Propietats de la imatge',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Restaura la mida',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Propietats de la imatge',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Falta la URL de la imatge.'
} );
