﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'cs', {
	alt: 'Alternativní text',
	btnUpload: 'Odeslat na server',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informace o obrázku',
	lockRatio: 'Zámek',
	menu: 'Vlastnosti obrázku',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Původní velikost',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Vlastnosti obrázku',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Zadané URL zdroje obrázku nebylo nalezeno.'
} );
