﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'cy', {
	alt: 'Testun Amgen',
	btnUpload: 'Anfon i\'r Gweinydd',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Gwyb Delwedd',
	lockRatio: 'Cloi Cymhareb',
	menu: 'Priodweddau Delwedd',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Ailosod Maint',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Priodweddau Delwedd',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'URL gwreiddiol y ddelwedd ar goll.'
} );
