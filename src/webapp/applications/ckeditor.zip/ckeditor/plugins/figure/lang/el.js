﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'el', {
	alt: 'Εναλλακτικό Κείμενο',
	btnUpload: 'Αποστολή στον Διακομιστή',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Πληροφορίες Εικόνας',
	lockRatio: 'Κλείδωμα Αναλογίας',
	menu: 'Ιδιότητες Εικόνας',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Επαναφορά Αρχικού Μεγέθους',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Ιδιότητες Εικόνας',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Το URL πηγής για την εικόνα λείπει.'
} );
