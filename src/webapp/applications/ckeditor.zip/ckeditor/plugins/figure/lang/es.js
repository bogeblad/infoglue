﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'es', {
	alt: 'Texto Alternativo',
	btnUpload: 'Enviar al Servidor',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Información de Imagen',
	lockRatio: 'Proporcional',
	menu: 'Propiedades de Imagen',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Tamaño Original',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Propiedades de Imagen',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Debe indicar la URL de la imagen.'
} );
