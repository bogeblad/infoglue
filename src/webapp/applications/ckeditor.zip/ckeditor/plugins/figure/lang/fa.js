﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'fa', {
	alt: 'متن جایگزین',
	btnUpload: 'به سرور بفرست',
	captioned: 'Captioned image', // MISSING
	infoTab: 'اطلاعات تصویر',
	lockRatio: 'قفل کردن نسبت',
	menu: 'ویژگی​های تصویر',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'بازنشانی اندازه',
	resizer: 'Click and drag to resize', // MISSING
	title: 'ویژگی​های تصویر',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'آدرس URL اصلی تصویر یافت نشد.'
} );
