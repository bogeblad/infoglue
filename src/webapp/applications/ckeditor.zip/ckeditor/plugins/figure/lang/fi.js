﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'fi', {
	alt: 'Vaihtoehtoinen teksti',
	btnUpload: 'Lähetä palvelimelle',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Kuvan tiedot',
	lockRatio: 'Lukitse suhteet',
	menu: 'Kuvan ominaisuudet',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Alkuperäinen koko',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Kuvan ominaisuudet',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Kuvan lähdeosoite puuttuu.'
} );
