﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'figure', 'fr', {
	alt: 'Texte de remplacement',
	btnUpload: 'Envoyer sur le serveur',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informations sur l\'image2',
	lockRatio: 'Conserver les proportions',
	menu: 'Propriétés de l\'image2',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Taille d\'origine',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Propriétés de l\'image2',
	uploadTab: 'Envoyer',
	urlMissing: 'L\'adresse source de l\'image est manquante.'
} );
