﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'gl', {
	alt: 'Texto alternativo',
	btnUpload: 'Enviar ao servidor',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Información da imaxe',
	lockRatio: 'Proporcional',
	menu: 'Propiedades da imaxe',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Tamaño orixinal',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Propiedades da imaxe',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Non se atopa o URL da imaxe.'
} );
