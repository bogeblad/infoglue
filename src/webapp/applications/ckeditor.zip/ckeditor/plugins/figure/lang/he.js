﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'he', {
	alt: 'טקסט חלופי',
	btnUpload: 'שליחה לשרת',
	captioned: 'Captioned image', // MISSING
	infoTab: 'מידע על התמונה',
	lockRatio: 'נעילת היחס',
	menu: 'תכונות התמונה',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'איפוס הגודל',
	resizer: 'Click and drag to resize', // MISSING
	title: 'מאפייני התמונה',
	uploadTab: 'העלאה',
	urlMissing: 'כתובת התמונה חסרה.'
} );
