﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'hu', {
	alt: 'Buborék szöveg',
	btnUpload: 'Küldés a szerverre',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Alaptulajdonságok',
	lockRatio: 'Arány megtartása',
	menu: 'Kép tulajdonságai',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Eredeti méret',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Kép tulajdonságai',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Hiányzik a kép URL-je'
} );
