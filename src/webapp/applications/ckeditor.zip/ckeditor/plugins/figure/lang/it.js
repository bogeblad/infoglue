﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'it', {
	alt: 'Testo alternativo',
	btnUpload: 'Invia al server',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informazioni immagine',
	lockRatio: 'Blocca rapporto',
	menu: 'Proprietà immagine',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Reimposta dimensione',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Proprietà immagine',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Manca l\'URL dell\'immagine.'
} );
