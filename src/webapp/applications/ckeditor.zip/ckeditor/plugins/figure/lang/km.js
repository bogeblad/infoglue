﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'km', {
	alt: 'អត្ថបទជំនួស',
	btnUpload: 'បញ្ជូនទៅកាន់ម៉ាស៊ីនផ្តល់សេវា',
	captioned: 'Captioned image', // MISSING
	infoTab: 'ពត៌មានអំពីរូបភាព',
	lockRatio: 'អត្រាឡុក',
	menu: 'ការកំណត់រូបភាព',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'កំណត់ទំហំឡើងវិញ',
	resizer: 'Click and drag to resize', // MISSING
	title: 'ការកំណត់រូបភាព',
	uploadTab: 'ផ្ទុក​ឡើង',
	urlMissing: 'Image source URL is missing.' // MISSING
} );
