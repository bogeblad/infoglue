﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'nb', {
	alt: 'Alternativ tekst',
	btnUpload: 'Send det til serveren',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Bildeinformasjon',
	lockRatio: 'Lås forhold',
	menu: 'Bildeegenskaper',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Tilbakestill størrelse',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Bildeegenskaper',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Bildets adresse mangler.'
} );
