﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'nl', {
	alt: 'Alternatieve tekst',
	btnUpload: 'Naar server verzenden',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informatie afbeelding',
	lockRatio: 'Afmetingen vergrendelen',
	menu: 'Eigenschappen afbeelding',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Afmetingen resetten',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Eigenschappen afbeelding',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'De URL naar de afbeelding ontbreekt.'
} );
