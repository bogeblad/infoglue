﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'pl', {
	alt: 'Tekst zastępczy',
	btnUpload: 'Wyślij',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informacje o obrazku',
	lockRatio: 'Zablokuj proporcje',
	menu: 'Właściwości obrazka',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Przywróć rozmiar',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Właściwości obrazka',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Podaj adres URL obrazka.'
} );
