﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'pt-br', {
	alt: 'Texto Alternativo',
	btnUpload: 'Enviar para o Servidor',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informações da Imagem',
	lockRatio: 'Travar Proporções',
	menu: 'Formatar Imagem',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Redefinir para o Tamanho Original',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Formatar Imagem',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'URL da imagem está faltando.'
} );
