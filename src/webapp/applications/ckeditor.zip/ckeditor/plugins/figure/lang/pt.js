﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'pt', {
	alt: 'Texto Alternativo',
	btnUpload: 'Enviar para o Servidor',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Informação da Imagem',
	lockRatio: 'Proporcional',
	menu: 'Propriedades da Imagem',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Tamanho Original',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Propriedades da Imagem',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'O URL da fonte da imagem está em falta.'
} );
