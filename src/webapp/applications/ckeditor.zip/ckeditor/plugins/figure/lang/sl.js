﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'sl', {
	alt: 'Nadomestno besedilo',
	btnUpload: 'Pošlji na strežnik',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Podatki o sliki',
	lockRatio: 'Zakleni razmerje',
	menu: 'Lastnosti slike',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Ponastavi velikost',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Lastnosti slike',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Manjka vir (URL) slike.'
} );
