﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'figure', 'sv', {
	alt: 'Alternativ text',
	btnUpload: 'Skicka till server',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Bildinformation',
	lockRatio: 'Lås höjd/bredd förhållanden',
	menu: 'Bildegenskaper',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Återställ storlek',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Bildegenskaper',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Bildkällans URL saknas.'
} );
