﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ug', {
	alt: 'تېكىست ئالماشتۇر',
	btnUpload: 'مۇلازىمېتىرغا يۈكلە',
	captioned: 'Captioned image', // MISSING
	infoTab: 'سۈرەت',
	lockRatio: 'نىسبەتنى قۇلۇپلا',
	menu: 'سۈرەت خاسلىقى',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'ئەسلى چوڭلۇق',
	resizer: 'Click and drag to resize', // MISSING
	title: 'سۈرەت خاسلىقى',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'سۈرەتنىڭ ئەسلى ھۆججەت ئادرېسى كەم'
} );
