﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'uk', {
	alt: 'Альтернативний текст',
	btnUpload: 'Надіслати на сервер',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Інформація про зображення',
	lockRatio: 'Зберегти пропорції',
	menu: 'Властивості зображення',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Очистити поля розмірів',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Властивості зображення',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Вкажіть URL зображення.'
} );
