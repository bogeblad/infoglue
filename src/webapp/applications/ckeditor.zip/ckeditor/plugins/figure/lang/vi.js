﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'vi', {
	alt: 'Chú thích ảnh',
	btnUpload: 'Tải lên máy chủ',
	captioned: 'Captioned image', // MISSING
	infoTab: 'Thông tin của ảnh',
	lockRatio: 'Giữ nguyên tỷ lệ',
	menu: 'Thuộc tính của ảnh',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Kích thước gốc',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Thuộc tính của ảnh',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Thiếu đường dẫn hình ảnh'
} );
