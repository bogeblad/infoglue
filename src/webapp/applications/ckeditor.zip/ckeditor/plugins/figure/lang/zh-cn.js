﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'zh-cn', {
	alt: '替换文本',
	btnUpload: '上传到服务器',
	captioned: 'Captioned image', // MISSING
	infoTab: '图象',
	lockRatio: '锁定比例',
	menu: '图象属性',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: '原始尺寸',
	resizer: 'Click and drag to resize', // MISSING
	title: '图象属性',
	uploadTab: 'Upload', // MISSING
	urlMissing: '缺少图像源文件地址'
} );
