﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'zh', {
	alt: '替代文字',
	btnUpload: '上傳至伺服器',
	captioned: 'Captioned image', // MISSING
	infoTab: '影像資訊',
	lockRatio: '等比例',
	menu: '影像屬性',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: '重設為原大小',
	resizer: 'Click and drag to resize', // MISSING
	title: '影像屬性',
	uploadTab: 'Upload', // MISSING
	urlMissing: 'Image source URL is missing.' // MISSING
} );
